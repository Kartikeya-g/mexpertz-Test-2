const path = require('path');
const fs = require('fs');
const { createObjectCsvWriter } = require('csv-writer');
const Student = require('../models/student'); // Assuming you have a Student model
const Interview = require('../models/interview'); // Assuming you have an Interview model

const ensureDirectoryExistence = (filePath) => {
  const dirname = path.dirname(filePath);
  if (fs.existsSync(dirname)) {
    return true;
  }
  ensureDirectoryExistence(dirname);
  fs.mkdirSync(dirname);
};

const generateStudentsCSV = async () => {
  const csvPath = path.join(__dirname, '..', 'exports', 'students_with_interviews.csv');
  ensureDirectoryExistence(csvPath);

  const csvWriter = createObjectCsvWriter({
    path: csvPath,
    header: [
      { id: 'studentId', title: 'Student ID' },
      { id: 'studentName', title: 'Student Name' },
      { id: 'studentCollege', title: 'Student College' },
      { id: 'studentStatus', title: 'Student Status' },
      { id: 'dsaScore', title: 'DSA Final Score' },
      { id: 'webdScore', title: 'WebD Final Score' },
      { id: 'reactScore', title: 'React Final Score' },
      { id: 'interviewDate', title: 'Interview Date' },
      { id: 'interviewCompany', title: 'Interview Company' },
      { id: 'interviewResult', title: 'Interview Result' }
    ],
  });

  // Fetch students and populate interviews
  const students = await Student.find().populate('interviews');

  // Flatten data for CSV
  const records = students.flatMap(student => 
    student.interviews.map(interview => ({
      // studentId: student._id,
      studentName: student.name,
      studentCollege: student.college,
      studentStatus: student.status,
      dsaScore: student.dsaScore,
      webdScore: student.webdScore,
      reactScore: student.reactScore,
      interviewDate: interview.date,
      interviewCompany: interview.company,
      interviewResult: interview.result  // This field should indicate 'Pass' or 'Fail'
    }))
  );

  try {
    await csvWriter.writeRecords(records);
    return { success: true, message: 'CSV file was created successfully' };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

module.exports = {
  generateStudentsCSV,
};
