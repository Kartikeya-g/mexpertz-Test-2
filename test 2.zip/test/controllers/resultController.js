const Result = require('../models/Result');

exports.getInterviewStudents = async (req, res) => {
  const { id } = req.params;
  try {
    const results = await Result.find({ interview: id }).populate('student');
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: 'Server Error' });
  }
};

exports.updateResults = async (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  try {
    for (const studentId in updates) {
      await Result.updateOne({ interview: id, student: studentId }, { result: updates[studentId] });
    }
    res.json({ message: 'Results updated' });
  } catch (error) {
    res.status(500).json({ error: 'Server Error' });
  }
};
