const Result = require('../models/Result');

exports.allocateStudentToInterview = async (req, res) => {
  const { studentId, interviewId } = req.body;
  try {
    const newResult = new Result({ student: studentId, interview: interviewId, result: 'On Hold' });
    await newResult.save();
    res.json(newResult);
  } catch (error) {
    res.status(500).json({ error: 'Server Error' });
  }
};
