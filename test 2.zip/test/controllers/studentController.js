const Student = require("../models/student");

exports.getStudents = async (req, res) => {
  try {
    const students = await Student.find();
    res.json(students);
  } catch (error) {
    res.status(500).json({ error: "Server Error" });
  }
};

exports.createStudent = async (req, res) => {
  const { name, college, status, dsaScore, webdScore, reactScore } = req.body;
  try {
    const newStudent = new Student({
      name,
      college,
      status,
      dsaScore,
      webdScore,
      reactScore,
    });
    await newStudent.save();
    res.json(newStudent);
  } catch (error) {
    res.status(500).json({ error: "Server Error" });
  }
};
