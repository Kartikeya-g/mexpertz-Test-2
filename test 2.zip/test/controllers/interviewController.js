const Interview = require('../models/interview');

exports.getInterviews = async (req, res) => {
  try {
    const interviews = await Interview.find();
    res.json(interviews);
  } catch (error) {
    res.status(500).json({ error: 'Server Error' });
  }
};

exports.createInterview = async (req, res) => {
  const { company, date } = req.body;
  try {
    const newInterview = new Interview({ company, date });
    await newInterview.save();
    res.json(newInterview);
  } catch (error) {
    res.status(500).json({ error: 'Server Error' });
  }
};
