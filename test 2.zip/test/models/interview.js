const mongoose = require('mongoose');

const interviewSchema = new mongoose.Schema({
  company: { type: String, required: true },
  date: { type: Date, required: true },
});

module.exports = mongoose.model('Interview', interviewSchema);
