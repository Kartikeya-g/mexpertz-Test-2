import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api'; // Adjust the base URL if needed

// Students
export const getStudents = async () => {
  const response = await axios.get(`${API_BASE_URL}/students`);
  return response.data;
};

export const createStudent = async (studentData) => {
  const response = await axios.post(`${API_BASE_URL}/students`, studentData);
  return response.data;
};

// Interviews
export const getInterviews = async () => {
  const response = await axios.get(`${API_BASE_URL}/interviews`);
  return response.data;
};

export const createInterview = async (interviewData) => {
  const response = await axios.post(`${API_BASE_URL}/interviews`, interviewData);
  return response.data;
};

// Allocate interview
export const allocateStudentToInterview = async (allocationData) => {
  const response = await axios.post(`${API_BASE_URL}/allocate`, allocationData);
  return response.data;
};
