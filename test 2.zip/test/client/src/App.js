import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Students from "./pages/Students";
import AllocateStudent from "./pages/AllocateStudent";
import Interviews from "./pages/Interviews";
import Navbar from "./components/Navbar";
import { AuthProvider } from "./context/AuthContext";
import PrivateRoute from "./components/PrivateRoute";

function App() {
  return (
    <AuthProvider>
      <Router>
        <div>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/students" element={<Students />} />
            <Route path="/allocate-student" element={<AllocateStudent />} />
            <Route path="/interviews" element={<Interviews />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
