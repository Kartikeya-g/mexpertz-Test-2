import React, { useContext } from 'react';
import { Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '../context/AuthContext';

const PrivateRoute = ({ element: Component, ...rest }) => {
  const { user } = useContext(AuthProvider);
  return (
    <Route
      {...rest}
      element={user ? <Component /> : <Navigate to="/login" />}
    />
  );
};

export default PrivateRoute;
