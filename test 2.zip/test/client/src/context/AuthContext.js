import React, { createContext, useState, useEffect } from "react";
// Corrected import statement for jwt-decode
import { jwtDecode } from "jwt-decode"; // Notice the change here
export const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [authToken, setAuthToken] = useState(
    localStorage.getItem("token") || null
  );
  const [user, setUser] = useState(authToken ? jwtDecode(authToken) : null);

  useEffect(() => {
    if (authToken) {
      setUser(jwtDecode(authToken));
    }
  }, [authToken]);

  const login = (token) => {
    localStorage.setItem("token", token);
    setAuthToken(token);
    setUser(jwtDecode(token));
  };

  const logout = () => {
    localStorage.removeItem("token");
    setAuthToken(null);
    setUser(null);
  };
  return (
    <AuthContext.Provider value={{ authToken, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
