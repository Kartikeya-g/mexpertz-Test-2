import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';

const Home = () => {
  return (
    <Container className="home-container text-center">
      <Row className="align-items-center justify-content-center min-vh-100">
        <Col md={8}>
          <h1 className="display-4">Welcome to the Placement Cell App</h1>
          <p className="lead">
            Manage all your student interviews and results efficiently with our easy-to-use interface.
          </p>
          <Button variant="primary" size="lg" className="mt-3">
            Get Started
          </Button>
        </Col>
      </Row>
    </Container>
  );
};

export default Home;
