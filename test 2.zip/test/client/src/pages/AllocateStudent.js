import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AllocateStudent = () => {
  const [students, setStudents] = useState([]);
  const [interviews, setInterviews] = useState([]);
  const [allocation, setAllocation] = useState({
    studentId: '',
    interviewId: ''
  });

  useEffect(() => {
    fetchStudents();
    fetchInterviews();
  }, []);

  const fetchStudents = async () => {
    const { data } = await axios.get('/api/students');
    setStudents(data);
  };

  const fetchInterviews = async () => {
    const { data } = await axios.get('/api/interviews');
    setInterviews(data);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAllocation({ ...allocation, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('/api/allocate', allocation);
  };

  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-md-6 offset-md-3">
          <div className="card shadow">
            <div className="card-body">
              <h2 className="card-title text-center mb-4">Allocate Student to Interview</h2>
              <form onSubmit={handleSubmit}>
                <div className="form-group mb-3">
                  <label htmlFor="studentId">Select Student</label>
                  <select
                    id="studentId"
                    className="form-control"
                    name="studentId"
                    value={allocation.studentId}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Student</option>
                    {students.map(student => (
                      <option key={student._id} value={student._id}>{student.name}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="interviewId">Select Interview</label>
                  <select
                    id="interviewId"
                    className="form-control"
                    name="interviewId"
                    value={allocation.interviewId}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Interview</option>
                    {interviews.map(interview => (
                      <option key={interview._id} value={interview._id}>{interview.company} - {new Date(interview.date).toLocaleDateString()}</option>
                    ))}
                  </select>
                </div>
                <button type="submit" className="btn btn-primary btn-block">Allocate</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AllocateStudent;
