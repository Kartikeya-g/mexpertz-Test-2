import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Students = () => {
  const [students, setStudents] = useState([]);
  const [newStudent, setNewStudent] = useState({
    name: '',
    college: '',
    status: '',
    dsaScore: 0,
    webdScore: 0,
    reactScore: 0,
  });

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    const { data } = await axios.get('/api/students');
    setStudents(data);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewStudent({ ...newStudent, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('/api/students', newStudent);
    fetchStudents();
  };

  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-md-6">
          <div className="card shadow">
            <div className="card-body">
              <h2 className="card-title text-center mb-4">Add New Student</h2>
              <form onSubmit={handleSubmit}>
                <div className="form-group mb-3">
                  <label htmlFor="name">Name</label>
                  <input
                    type="text"
                    id="name"
                    className="form-control"
                    placeholder="Enter student name"
                    name="name"
                    value={newStudent.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="college">College</label>
                  <input
                    type="text"
                    id="college"
                    className="form-control"
                    placeholder="Enter college name"
                    name="college"
                    value={newStudent.college}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="status">Status</label>
                  <select
                    id="status"
                    className="form-control"
                    name="status"
                    value={newStudent.status}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select status</option>
                    <option value="placed">Placed</option>
                    <option value="not_placed">Not Placed</option>
                  </select>
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="dsaScore">DSA Score</label>
                  <input
                    type="number"
                    id="dsaScore"
                    className="form-control"
                    name="dsaScore"
                    value={newStudent.dsaScore}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="webdScore">WebD Score</label>
                  <input
                    type="number"
                    id="webdScore"
                    className="form-control"
                    name="webdScore"
                    value={newStudent.webdScore}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="reactScore">React Score</label>
                  <input
                    type="number"
                    id="reactScore"
                    className="form-control"
                    name="reactScore"
                    value={newStudent.reactScore}
                    onChange={handleChange}
                    required
                  />
                </div>
                <button type="submit" className="btn btn-primary btn-block">Add Student</button>
              </form>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <h2 className="text-center mb-4">List of Students</h2>
          <ul className="list-group">
            {students.map(student => (
              <li key={student._id} className="list-group-item">
                {student.name} - {student.college}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Students;
