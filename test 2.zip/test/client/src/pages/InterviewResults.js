import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const InterviewResults = () => {
  const { id } = useParams();
  const [students, setStudents] = useState([]);
  const [results, setResults] = useState({});

  useEffect(() => {
    fetchInterviewStudents();
  }, []);

  const fetchInterviewStudents = async () => {
    const { data } = await axios.get(`/api/interviews/${id}/students`);
    setStudents(data);
    const initialResults = data.reduce((acc, student) => {
      acc[student._id] = student.result || '';
      return acc;
    }, {});
    setResults(initialResults);
  };

  const handleResultChange = (studentId, result) => {
    setResults({ ...results, [studentId]: result });
  };

  const handleSaveResults = async () => {
    await axios.post(`/api/interviews/${id}/results`, results);
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Interview Results</h2>
      <ul className="list-group">
        {students.map(student => (
          <li key={student._id} className="list-group-item d-flex justify-content-between align-items-center">
            <span>{student.name}</span>
            <select
              value={results[student._id]}
              onChange={(e) => handleResultChange(student._id, e.target.value)}
            >
              <option value="">Select Result</option>
              <option value="PASS">PASS</option>
              <option value="FAIL">FAIL</option>
              <option value="On Hold">On Hold</option>
              <option value="Didn’t Attempt">Didn’t Attempt</option>
            </select>
          </li>
        ))}
      </ul>
      <button onClick={handleSaveResults} className="btn btn-primary btn-block mt-4">Save Results</button>
    </div>
  );
};

export default InterviewResults;
