import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Interviews = () => {
  const [interviews, setInterviews] = useState([]);
  const [newInterview, setNewInterview] = useState({
    company: '',
    date: ''
  });

  useEffect(() => {
    fetchInterviews();
  }, []);

  const fetchInterviews = async () => {
    const { data } = await axios.get('/api/interviews');
    setInterviews(data);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewInterview({ ...newInterview, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('/api/interviews', newInterview);
    fetchInterviews();
  };

  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-md-6">
          <div className="card shadow">
            <div className="card-body">
              <h2 className="card-title text-center mb-4">Add New Interview</h2>
              <form onSubmit={handleSubmit}>
                <div className="form-group mb-3">
                  <label htmlFor="company">Company Name</label>
                  <input
                    type="text"
                    id="company"
                    className="form-control"
                    placeholder="Enter company name"
                    name="company"
                    value={newInterview.company}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group mb-3">
                  <label htmlFor="date">Date</label>
                  <input
                    type="date"
                    id="date"
                    className="form-control"
                    name="date"
                    value={newInterview.date}
                    onChange={handleChange}
                    required
                  />
                </div>
                <button type="submit" className="btn btn-primary btn-block">Add Interview</button>
              </form>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <h2 className="text-center mb-4">List of Interviews</h2>
          <ul className="list-group">
            {interviews.map(interview => (
              <li key={interview._id} className="list-group-item">
                {interview.company} - {new Date(interview.date).toLocaleDateString()}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Interviews;
