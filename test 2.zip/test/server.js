const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

const studentRoutes = require("./routes/studentRoutes");
const interviewRoutes = require("./routes/interviewRoutes");
const allocationRoutes = require("./routes/allocationRoutes");
const resultRoutes = require("./routes/resultRoutes");
const authRoutes = require("./routes/authRoutes");

const app = express();

mongoose.connect("mongodb+srv://kartik:kartik@cluster0.7n7hi53.mongodb.net/", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.use(bodyParser.json());

app.use("/api/auth", authRoutes);
app.use("/api/students", studentRoutes);
app.use("/api/interviews", interviewRoutes);
app.use("/api/allocate", allocationRoutes);
app.use("/api/interviews", resultRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
