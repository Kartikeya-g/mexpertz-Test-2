const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const {
  getInterviews,
  createInterview,
} = require("../controllers/interviewController");

router.get("/", getInterviews);
router.post("/", createInterview);

module.exports = router;
