const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const {
  getInterviewStudents,
  updateResults,
} = require("../controllers/resultController");

router.get("/:id/students", getInterviewStudents);
router.post("/:id/results", updateResults);

module.exports = router;
